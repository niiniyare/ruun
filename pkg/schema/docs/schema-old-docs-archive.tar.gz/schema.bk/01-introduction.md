## Section 1: Introduction - Schema-Driven UI for Go SSR

### 🎯 Learning Objectives

By the end of this section, you will understand:
- What schema-driven development is and why it matters
- The difference between SSR and SPA approaches
- How this system was inspired by amis but solves its limitations
- Who should use this system and when
- The architecture and technology stack

### 1.1 What is Schema-Driven Development?

Schema-driven development is an architectural pattern where **backend developers define complete user interfaces using declarative JSON schemas** instead of writing frontend code. The schema acts as a **contract** between backend and frontend, describing:

- ✅ What fields exist and their types
- ✅ What validation rules apply
- ✅ What layout structure is desired
- ✅ What permissions control access
- ✅ What events trigger actions

This approach separates **WHAT** (schema definition) from **HOW** (rendering implementation).

**Traditional Approach:**
```
Backend Dev → Writes API
Frontend Dev → Writes React/Vue components → Implements validation → Handles state
Product Manager → Coordinates between teams
Result: 2-3 week delivery time
```

**Schema-Driven Approach:**
```
Backend Dev → Writes JSON schema → Done
Server → Renders HTML from schema
Browser → Receives ready HTML
Result: Same-day delivery
```

**Example Schema:**
```json
{
  "id": "contact-form",
  "type": "form",
  "title": "Contact Us",
  "fields": [
    {
      "name": "email",
      "type": "email",
      "label": "Email Address",
      "required": true,
      "validation": {
        "maxLength": 255,
        "messages": {
          "required": "Email is required"
        }
      }
    },
    {
      "name": "message",
      "type": "textarea",
      "label": "Message",
      "required": true
    }
  ],
  "config": {
    "action": "/api/contact",
    "method": "POST"
  }
}
```

**This JSON becomes:**
- ✅ HTML form with proper attributes
- ✅ Client-side validation (HTML5)
- ✅ Server-side validation (Go)
- ✅ HTMX-powered submission
- ✅ Error handling
- ✅ Success feedback

**No frontend code required.**

### 1.2 Why Server-Side Rendering (SSR) Over Single-Page Applications (SPA)?

This system uses **Server-Side Rendering with progressive enhancement** instead of client-side SPA frameworks.

#### Performance Comparison

| Metric | SPA (React/Vue) | SSR (templ + HTMX) | Winner |
|--------|-----------------|---------------------|---------|
| Initial Load | 1-3MB JS bundle | 10-50KB HTML | ✅ SSR |
| First Contentful Paint | 2-5 seconds | ~200ms | ✅ SSR |
| Time to Interactive | 3-5 seconds | Immediate | ✅ SSR |
| Works without JS | ❌ No | ✅ Yes | ✅ SSR |
| SEO Friendly | Needs SSR setup | Native | ✅ SSR |
| Type Safety | TypeScript (optional) | Go (compile-time) | ✅ SSR |
| Debugging | Complex (DevTools + source maps) | View source | ✅ SSR |
| Build Process | webpack/vite (complex) | Go build (simple) | ✅ SSR |
| State Management | Redux/Vuex/Context | Server state | ✅ SSR |
| Caching | Complex (service workers) | HTTP caching | ✅ SSR |

#### Architecture Flow

**SPA Approach:**
```
Browser                 Server
   │                       │
   ├─── GET /page ────────→│
   │←──── index.html ──────┤ (empty shell)
   │                       │
   ├─── GET bundle.js ────→│
   │←──── 2MB JS ──────────┤
   │                       │
   │ (Parse + Execute JS)  │
   │ (React renders)       │
   │                       │
   ├─── GET /api/data ────→│
   │←──── JSON ────────────┤
   │                       │
   │ (React re-renders)    │
   │                       │
   User sees content (3-5s)
```

**SSR Approach:**
```
Browser                 Server
   │                       │
   ├─── GET /page ────────→│
   │                       │ (Parse schema)
   │                       │ (Enrich with permissions)
   │                       │ (Render with templ)
   │                       │
   │←──── Full HTML ───────┤
   │                       │
   User sees content (200ms)
   │                       │
   │ (HTMX enhances)       │
   │ (Alpine.js for state) │
```

#### When to Use Each

**Use SSR (this system) when:**
- ✅ Building enterprise forms and CRUD interfaces
- ✅ SEO is important
- ✅ Performance is critical
- ✅ Team is primarily backend developers
- ✅ Need simple deployment (single binary)
- ✅ Want type safety (Go)

**Use SPA when:**
- ❌ Building highly interactive apps (games, drawing tools)
- ❌ Need offline-first capability
- ❌ Complex client-side state management required
- ❌ Real-time collaboration (Google Docs-style)

### 1.3 The amis Inspiration - Keeping Pros, Solving Cons

**amis** (by Baidu, https://baidu.github.io/amis) is a popular JSON-based UI schema system that inspired this project.

#### What amis Does Well (We Keep These)

| amis Feature | Our Implementation | Status |
|--------------|-------------------|---------|
| **JSON-Driven UI** | ✅ Identical approach | Implemented |
| **Declarative** | ✅ Same philosophy | Implemented |
| **Rich Components** | ✅ 40+ field types | Implemented |
| **Backend Controls** | ✅ Server authority | Implemented |
| **Low-Code Ready** | ✅ Visual builder support | Designed for |
| **Validation** | ✅ HTML5 + server rules | Enhanced |

#### What amis Struggles With (We Solve These)

| amis Problem | Why It's a Problem | Our Solution | Benefit |
|--------------|-------------------|--------------|----------|
| **React Dependency** | 1-3MB bundle size | templ (Go templates) | ~10KB HTML |
| **SPA Architecture** | Slow initial load | SSR with progressive enhancement | Instant load |
| **Complex Build** | webpack, babel, etc. | Go build only | Simple deployment |
| **Learning Curve** | React + amis syntax | Go + simple JSON | Easier onboarding |
| **Type Safety** | Runtime errors in JS | Compile-time in Go | Fewer bugs |
| **Customization** | Hard to extend | Full Go code access | Complete control |
| **Performance** | Client-side rendering | Server-side rendering + caching | Faster pages |

#### Architecture Comparison

**amis (React SPA):**
```
┌─────────────────────────────────────┐
│  Browser                            │
│                                     │
│  ┌──────────────────────────────┐  │
│  │  React App (1.5MB)           │  │
│  │  ├─ amis Library (800KB)     │  │
│  │  ├─ React (150KB)            │  │
│  │  └─ Dependencies (550KB)     │  │
│  └──────────────────────────────┘  │
│           │                         │
│           ▼                         │
│  Fetch JSON Schema                  │
│           │                         │
└───────────┼─────────────────────────┘
            │
            ▼
     ┌──────────────┐
     │   Server     │
     │  Returns     │
     │  JSON Schema │
     └──────────────┘
```

**Our System (Go SSR):**
```
┌─────────────────────────────────────┐
│  Browser                            │
│                                     │
│  ┌──────────────────────────────┐  │
│  │  HTML (50KB)                 │  │
│  │  ├─ HTMX (14KB)              │  │
│  │  └─ Alpine.js (15KB)         │  │
│  └──────────────────────────────┘  │
│                                     │
└─────────────────────────────────────┘
            ▲
            │
     ┌──────────────┐
     │   Server     │
     │  (Go)        │
     │  ├─ Parse    │
     │  ├─ Enrich   │
     │  ├─ Render   │
     │  └─ Return   │
     │     HTML     │
     └──────────────┘
```

**Key Insight:** We keep amis's brilliant idea (JSON-driven UI) but change the execution (SSR instead of SPA).

### 1.4 Target Audience and Use Cases

#### Who Should Use This System?

**Primary Users:**
- ✅ **Backend Developers** - Write JSON, get working UI
- ✅ **Full-Stack Developers** - Focus on Go, minimal frontend work
- ✅ **Enterprise Teams** - Need consistent, secure forms
- ✅ **Rapid Prototyping** - Build UIs in minutes, not days

**Secondary Users:**
- ✅ **Product Managers** - Understand UI through JSON schema
- ✅ **Low-Code Builders** - Visual tools generate JSON
- ✅ **API-First Teams** - Backend-driven development

#### Ideal Use Cases

**✅ Perfect For:**
1. **Enterprise Forms**
   - User registration
   - Customer onboarding
   - Data entry forms
   - Settings pages
   - Configuration UIs

2. **CRUD Operations**
   - Create/Read/Update/Delete interfaces
   - Admin panels
   - Management dashboards
   - Data tables with filters

3. **Multi-Step Workflows**
   - Registration wizards
   - Checkout processes
   - Survey forms
   - Approval workflows

4. **Dynamic Forms**
   - Forms that change based on user role
   - Conditional field visibility
   - Permission-based access
   - Tenant-specific customization

5. **ERP Systems**
   - Invoice management
   - Inventory tracking
   - Customer relationships
   - Financial reporting

**❌ Not Ideal For:**
1. **Highly Interactive Apps**
   - Real-time collaboration (Google Docs)
   - Drawing/design tools
   - Games
   - Video/audio editing

2. **Marketing Sites**
   - Landing pages with animations
   - Interactive storytelling
   - Complex scroll effects

3. **Mobile-First Apps**
   - Use native mobile frameworks
   - This is for web applications

### 1.5 System Architecture Overview

#### The Three-Layer Architecture

```
┌──────────────────────────────────────────────────────┐
│  Layer 1: Schema Definition (Pure Data)              │
│                                                       │
│  JSON Schema → Go Struct → Validation                │
│  ├─ Fields, Types, Labels                            │
│  ├─ Validation Rules                                 │
│  ├─ Layout Structure                                 │
│  └─ Permissions, Events                              │
└────────────────────┬──────────────────────────────────┘
                     │
                     ▼
┌──────────────────────────────────────────────────────┐
│  Layer 2: Processing (Go Logic)                      │
│                                                       │
│  ├─ Parser:    JSON → Schema struct                  │
│  ├─ Validator: Check rules                           │
│  ├─ Enricher:  Add runtime data (permissions, etc.)  │
│  └─ Registry:  Store and cache schemas               │
└────────────────────┬──────────────────────────────────┘
                     │
                     ▼
┌──────────────────────────────────────────────────────┐
│  Layer 3: Rendering (templ Components)               │
│                                                       │
│  Schema → templ → HTML                               │
│  ├─ Field type → Component mapping                   │
│  ├─ Validation → HTML attributes                     │
│  ├─ HTMX → Progressive enhancement                   │
│  └─ Alpine.js → Client state                         │
└──────────────────────────────────────────────────────┘
```

#### Technology Stack

**Backend:**
- **Go 1.21+** - Type-safe, compiled language
- **templ** - Type-safe Go templates
- **go-playground/validator** - Struct validation
- **condition package** - Business rules engine (existing)

**Frontend:**
- **HTMX 1.9+** - HTML over the wire
- **Alpine.js 3.x** - Minimal reactive framework
- **Standard HTML5** - Native form validation
- **Modern CSS** - Grid, Flexbox (optional Tailwind)

**Database:**
- **PostgreSQL 14+** - Schema storage
- **Redis** (optional) - Schema caching

#### Request Flow

**Complete Request Lifecycle:**

```
1. Browser Request
   │
   ├─→ GET /forms/contact
   │
2. HTTP Handler (Go)
   │
   ├─→ registry.Get("contact-form")
   │     │
   │     ├─→ Check cache (Redis)
   │     ├─→ If not cached, load from PostgreSQL
   │     └─→ Return *Schema
   │
3. Enricher
   │
   ├─→ Get user from context
   ├─→ Load user permissions
   ├─→ Add runtime flags (visible, editable)
   └─→ Return enriched *Schema
   │
4. templ Renderer
   │
   ├─→ FormPage(schema, data)
   │     │
   │     ├─→ Loop through fields
   │     ├─→ Render field components
   │     ├─→ Add HTMX attributes
   │     └─→ Generate HTML
   │
5. Response
   │
   └─→ Send HTML to browser (with headers, caching)
   │
6. Browser
   │
   ├─→ Display HTML immediately
   ├─→ HTMX enhances form submission
   └─→ Alpine.js manages client state
```

### 1.6 Design Principles

#### Principle 1: Backend is Source of Truth

**All security-critical decisions happen on the server.**

```go
// ❌ WRONG: Client decides visibility
<input x-show="user.role === 'admin'" />

// ✅ RIGHT: Server decides, client respects
field.Runtime = &FieldRuntime{
    Visible: user.HasPermission("view_salary"),
}
```

**Why?** Client code can be manipulated. Server is trusted.

#### Principle 2: Schema is Pure Contract

**Schema defines WHAT, not HOW.**

```json
// ✅ GOOD: Describes structure
{
  "name": "email",
  "type": "email",
  "required": true
}

// ❌ BAD: Includes implementation
{
  "name": "email",
  "component": "MyEmailComponent",
  "reactProps": { ... }
}
```

**Why?** Keeps schema technology-agnostic. Can render with any framework.

#### Principle 3: Progressive Enhancement

**HTML works without JavaScript. JS enhances experience.**

```html
<!-- Base HTML form (works without JS) -->
<form action="/api/submit" method="POST">
  <input type="email" name="email" required />
  <button type="submit">Submit</button>
</form>

<!-- HTMX enhances (AJAX submission) -->
<form hx-post="/api/submit" hx-target="#result">
  <input type="email" name="email" required />
  <button type="submit">Submit</button>
</form>

<!-- Alpine.js adds state (error messages) -->
<form hx-post="/api/submit" x-data="{ error: '' }">
  <input type="email" name="email" required @invalid="error = $el.validationMessage" />
  <span x-show="error" x-text="error"></span>
  <button type="submit">Submit</button>
</form>
```

**Why?** Resilient. Works even if JS fails to load or is disabled.

#### Principle 4: Type Safety Throughout

**Go's type system prevents runtime errors.**

```go
// ✅ Compile-time type checking
type Schema struct {
    ID     string      `json:"id"`
    Type   SchemaType  `json:"type"`  // Enum
    Fields []Field     `json:"fields"` // Typed slice
}

// ❌ vs JavaScript (runtime errors)
const schema = {
    id: "form",
    type: "forrm",  // Typo! Only caught at runtime
    fields: "not an array"  // Wrong type! Only caught at runtime
}
```

**Why?** Catch errors at compile-time, not in production.

#### Principle 5: Convention Over Configuration

**Sensible defaults for common cases.**

```go
// Minimal configuration
schema := NewSchema("user-form", TypeForm, "Create User")
schema.AddField(Field{
    Name:     "email",
    Type:     FieldEmail,
    Label:    "Email",
    Required: true,
})
// Defaults:
// - Encoding: application/json
// - Method: POST
// - Timeout: 30s
// - CSRF: enabled
// - Cache: enabled
```

**Why?** Fast development for 80% of use cases. Override when needed.

---

